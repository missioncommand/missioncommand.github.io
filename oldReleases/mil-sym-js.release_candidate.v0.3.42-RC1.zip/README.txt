0.3.42-RC1

Changes since 0.3.37:
-Fixed Hierarchy property bug in SymbolDef & SymbolDefTable
-Fix for BS_CROSS-------, code 1 character too long
-Fix for BS_ELLIPSE-----, changed fom 3 point to 1 point with AM[2] and AN[1] modifiers
-Fix for direction of line pattern in Limited Access Area